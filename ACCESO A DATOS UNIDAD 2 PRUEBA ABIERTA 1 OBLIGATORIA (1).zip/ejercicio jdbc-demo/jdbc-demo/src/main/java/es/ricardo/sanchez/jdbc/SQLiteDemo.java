package es.ricardo.sanchez.jdbc;

import java.sql.*;

public class SQLiteDemo {

    public static void main(String[] args) {
        // BD embebida: se crea como archivo local (en nuestro proyecto o en la carpeta donde ejecutemos)
        String url = "jdbc:sqlite:tienda_sqlite.db";

        try (Connection conn = DriverManager.getConnection(url)) {

            System.out.println("✅ Conectado a SQLite (SGBD embebido)");
            System.out.println("URL: " + conn.getMetaData().getURL());

            // 1) Transacción
            conn.setAutoCommit(false);

            try {
                // 2) Crear estructura (tabla) si no existe
                try (Statement st = conn.createStatement()) {
                    st.executeUpdate("""
                        CREATE TABLE IF NOT EXISTS producto (
                          id INTEGER PRIMARY KEY AUTOINCREMENT,
                          nombre TEXT NOT NULL,
                          precio REAL NOT NULL
                        )
                    """);
                }

                // 3) Insertar un registro
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO producto(nombre, precio) VALUES (?, ?)")) {
                    ps.setString(1, "Pantalón");
                    ps.setDouble(2, 29.95);
                    ps.executeUpdate();
                }

                // 4) Consultar para comprobar
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT id, nombre, precio FROM producto ORDER BY id DESC LIMIT 5");
                     ResultSet rs = ps.executeQuery()) {

                    System.out.println("\nÚltimos 5 productos:");
                    while (rs.next()) {
                        System.out.printf(" - %d | %s | %.2f%n",
                                rs.getInt("id"),
                                rs.getString("nombre"),
                                rs.getDouble("precio"));
                    }
                }

                // 5) Commit
                conn.commit();
                System.out.println("\n✅ Commit realizado correctamente.");

            } catch (Exception e) {
                // 6) Rollback si hay fallo
                conn.rollback();
                System.out.println("\n❌ Error. Rollback ejecutado: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.out.println("❌ No se pudo conectar a SQLite.");
            e.printStackTrace();
        }
    }
}
