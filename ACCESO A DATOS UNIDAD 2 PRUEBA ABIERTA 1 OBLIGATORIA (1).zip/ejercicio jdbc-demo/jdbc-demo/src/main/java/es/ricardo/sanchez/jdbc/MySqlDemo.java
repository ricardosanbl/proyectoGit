package es.ricardo.sanchez.jdbc;

import java.math.BigDecimal;
import java.sql.*;

public class MySqlDemo {

    public static void main(String[] args) {

        // ⚠️ Cambia usuario/contraseña si los tuyos son otros
        String url = "jdbc:mysql://localhost:3306/tienda?useSSL=false&serverTimezone=UTC";
        String user = "root";
        String pass = "richi2000";

        try (Connection conn = DriverManager.getConnection(url, user, pass)) {

            System.out.println("✅ Conectado a MySQL (SGBD independiente)");
            System.out.println("URL: " + conn.getMetaData().getURL());

            // 1) Transacción
            conn.setAutoCommit(false);

            try {
                // 2) Crear estructura si no existe (tabla)
                try (Statement st = conn.createStatement()) {
                    st.executeUpdate("""
                        CREATE TABLE IF NOT EXISTS producto (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          nombre VARCHAR(100) NOT NULL,
                          precio DECIMAL(10,2) NOT NULL
                        )
                    """);
                }

                // 3) Procedimiento almacenado (CALL)
                try (CallableStatement cs = conn.prepareCall("{ call sp_insertar_producto(?, ?) }")) {
                    cs.setString(1, "Camiseta");
                    cs.setBigDecimal(2, new BigDecimal("19.99"));
                    cs.execute();
                }

                // 4) Consulta para comprobar inserción
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT id, nombre, precio FROM producto ORDER BY id DESC LIMIT 5");
                     ResultSet rs = ps.executeQuery()) {

                    System.out.println("\nÚltimos 5 productos:");
                    while (rs.next()) {
                        System.out.printf(" - %d | %s | %s%n",
                                rs.getInt("id"),
                                rs.getString("nombre"),
                                rs.getBigDecimal("precio"));
                    }
                }

                // 5) Confirmar transacción
                conn.commit();
                System.out.println("\n✅ Commit realizado correctamente.");

            } catch (Exception e) {
                // 6) Revertir si falla algo
                conn.rollback();
                System.out.println("\n❌ Error. Rollback ejecutado: " + e.getMessage());
            }

            // try-with-resources cierra Connection, Statements y ResultSet automáticamente

        } catch (SQLException e) {
            System.out.println("❌ No se pudo conectar a MySQL. Revisa URL/usuario/contraseña y que MySQL esté encendido.");
            e.printStackTrace();
        }
    }
}
