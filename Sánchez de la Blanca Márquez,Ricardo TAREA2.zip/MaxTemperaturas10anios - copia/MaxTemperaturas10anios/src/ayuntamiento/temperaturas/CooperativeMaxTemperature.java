package ayuntamiento.temperaturas;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CooperativeMaxTemperature {

    // Constantes del problema
    private static final int DIAS = 3650;       // ~10 años
    private static final int MIN_TEMP = -30;
    private static final int MAX_TEMP = 50;

    public static void main(String[] args) {
        // 1) Simular datos: temperaturas diarias aleatorias en [-30, 50]
        int[] temperaturas = generarTemperaturas(DIAS, MIN_TEMP, MAX_TEMP);

        // 2) Elegir número de partes/hilos: mínimo 8, o núcleos de la máquina
        int nucleos = Runtime.getRuntime().availableProcessors();
        int partes = Math.max(8, nucleos);

        // 3) Crear tareas (una por segmento)
        List<Callable<Integer>> tareas = new ArrayList<>();
        int tamSegmento = (int) Math.ceil((double) temperaturas.length / partes);

        for (int i = 0; i < partes; i++) {
            int inicio = i * tamSegmento;
            int fin = Math.min(inicio + tamSegmento, temperaturas.length);
            if (inicio >= fin) break; // seguridad
            final int from = inicio;
            final int to = fin;

            tareas.add(() -> maxEnRango(temperaturas, from, to));
        }

        // 4) Ejecutar en un pool y recoger máximos parciales
        ExecutorService pool = Executors.newFixedThreadPool(partes);
        int maxGlobal = Integer.MIN_VALUE;

        try {
            List<Future<Integer>> resultados = pool.invokeAll(tareas);
            for (Future<Integer> f : resultados) {
                int maxParcial = f.get();
                if (maxParcial > maxGlobal) {
                    maxGlobal = maxParcial;
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        } finally {
            pool.shutdown();
        }

        // 5) Mostrar resultado
        System.out.println("Temperatura máxima de los últimos 10 años: " + maxGlobal + " °C");
    }

    // Genera un array de tamaño n con enteros aleatorios en [min, max]
    private static int[] generarTemperaturas(int n, int min, int max) {
        int[] datos = new int[n];
        Random r = new Random(); // para reproducibilidad, usa: new Random(42);
        for (int i = 0; i < n; i++) {
            datos[i] = r.nextInt((max - min) + 1) + min;
        }
        return datos;
    }

    // Devuelve el máximo en el intervalo [inicio, fin)
    private static int maxEnRango(int[] arr, int inicio, int fin) {
        int max = Integer.MIN_VALUE;
        for (int i = inicio; i < fin; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }
}
