package ayuntamiento.temperaturas;

public class CooperativeMaxTemperatureThreads {

    private static final int DIAS = 3650;
    private static final int MIN_TEMP = -30;
    private static final int MAX_TEMP = 50;

    public static void main(String[] args) throws InterruptedException {
        int[] temperaturas = generarTemperaturas(DIAS, MIN_TEMP, MAX_TEMP);

        int nucleos = Runtime.getRuntime().availableProcessors();
        int partes = Math.max(8, nucleos);
        int tamSegmento = (int) Math.ceil((double) temperaturas.length / partes);

        int[] maxParciales = new int[partes];
        Thread[] hilos = new Thread[partes];

        for (int i = 0; i < partes; i++) {
            int idx = i;
            int inicio = i * tamSegmento;
            int fin = Math.min(inicio + tamSegmento, temperaturas.length);

            if (inicio >= fin) {
                maxParciales[i] = Integer.MIN_VALUE;
                continue;
            }

            hilos[i] = new Thread(() -> {
                int max = Integer.MIN_VALUE;
                for (int j = inicio; j < fin; j++) {
                    if (temperaturas[j] > max) {
                        max = temperaturas[j];
                    }
                }
                maxParciales[idx] = max;
            });

            hilos[i].start();
        }

        // Esperar a que todos terminen
        for (Thread t : hilos) {
            if (t != null) t.join();
        }

        // Reducción
        int maxGlobal = Integer.MIN_VALUE;
        for (int m : maxParciales) {
            if (m > maxGlobal) maxGlobal = m;
        }

        System.out.println("Temperatura máxima de los últimos 10 años: " + maxGlobal + " °C");
    }

    private static int[] generarTemperaturas(int n, int min, int max) {
        int[] datos = new int[n];
        java.util.Random r = new java.util.Random();
        for (int i = 0; i < n; i++) {
            datos[i] = r.nextInt((max - min) + 1) + min;
        }
        return datos;
    }
}

