package com.empresa.reserva;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ReservaController {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApellido1;
    @FXML
    private TextField txtApellido2;
    @FXML
    private TextField txtEmpresa;
    @FXML
    private TextField txtEmail;
    @FXML
    private Spinner<Integer> spnAcompanantes;
    @FXML
    private TextArea txtObservaciones;
    @FXML
    private Button btnReservar;

    @FXML
    private void initialize() {
        SpinnerValueFactory<Integer> valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10, 0);
        spnAcompanantes.setValueFactory(valueFactory);
    }

    @FXML
    private void onReservarAction(ActionEvent event) {
        Reserva reserva = new Reserva();
        reserva.setNombre(txtNombre.getText());
        reserva.setApellido1(txtApellido1.getText());
        reserva.setApellido2(txtApellido2.getText());
        reserva.setEmpresa(txtEmpresa.getText());
        reserva.setEmail(txtEmail.getText());
        reserva.setNumAcompanantes(spnAcompanantes.getValue());
        reserva.setObservaciones(txtObservaciones.getText());

        if (!ReservaValidator.camposObligatoriosCompletos(reserva)) {
            mostrarAlerta(Alert.AlertType.ERROR,
                    "Error de validación",
                    "Todos los campos obligatorios deben estar completos.");
            return;
        }

        if (!ReservaValidator.emailValido(reserva.getEmail())) {
            mostrarAlerta(Alert.AlertType.ERROR,
                    "Error de validación",
                    "El correo electrónico debe tener la forma usuario@dominio.es.");
            return;
        }

        mostrarAlerta(Alert.AlertType.INFORMATION,
                "Reserva correcta",
                "La reserva se ha realizado correctamente.");
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
