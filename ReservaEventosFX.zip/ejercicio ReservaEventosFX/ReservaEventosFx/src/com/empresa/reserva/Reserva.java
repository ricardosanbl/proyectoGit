package com.empresa.reserva;

public class Reserva {

    private String nombre;
    private String apellido1;
    private String apellido2;
    private String empresa;
    private String email;
    private int numAcompanantes;
    private String observaciones;

    public String getNombre() { 
        return nombre; 
    }
    public void setNombre(String nombre) { 
        this.nombre = nombre; 
    }

    public String getApellido1() { 
        return apellido1; 
    }
    public void setApellido1(String apellido1) { 
        this.apellido1 = apellido1; 
    }

    public String getApellido2() { 
        return apellido2; 
    }
    public void setApellido2(String apellido2) { 
        this.apellido2 = apellido2; 
    }

    public String getEmpresa() { 
        return empresa; 
    }
    public void setEmpresa(String empresa) { 
        this.empresa = empresa; 
    }

    public String getEmail() { 
        return email; 
    }
    public void setEmail(String email) { 
        this.email = email; 
    }

    public int getNumAcompanantes() { 
        return numAcompanantes; 
    }
    public void setNumAcompanantes(int numAcompanantes) { 
        this.numAcompanantes = numAcompanantes; 
    }

    public String getObservaciones() { 
        return observaciones; 
    }
    public void setObservaciones(String observaciones) { 
        this.observaciones = observaciones; 
    }
}

