package com.empresa.reserva;

public class ReservaValidator {

    private static boolean estaVacio(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static boolean camposObligatoriosCompletos(Reserva r) {
        return !estaVacio(r.getNombre())
            && !estaVacio(r.getApellido1())
            && !estaVacio(r.getApellido2())
            && !estaVacio(r.getEmpresa())
            && !estaVacio(r.getEmail());
    }

    public static boolean emailValido(String email) {
        if (estaVacio(email)) return false;
        // correo que termine en .es
        return email.matches("^[^@\\s]+@[^@\\s]+\\.es$");
    }
}
