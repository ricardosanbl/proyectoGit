package com.empresa.reserva;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ReservaValidatorTest {

    // Crea una reserva "válida" base para reutilizar en varios tests
    private Reserva crearReservaBasica() {
        Reserva r = new Reserva();
        r.setNombre("Ricardo");
        r.setApellido1("Pérez");
        r.setApellido2("López");
        r.setEmpresa("MiEmpresa");
        r.setEmail("usuario@empresa.es");
        r.setNumAcompanantes(2);
        r.setObservaciones("Sin observaciones");
        return r;
    }

    // ---------- TESTS CAMPOS OBLIGATORIOS ----------

    @Test
    void camposObligatoriosCompletos_todoRelleno_devuelveTrue() {
        Reserva r = crearReservaBasica();
        assertTrue(ReservaValidator.camposObligatoriosCompletos(r));
    }

    @Test
    void camposObligatoriosCompletos_faltaNombre_devuelveFalse() {
        Reserva r = crearReservaBasica();
        r.setNombre("");  // nombre vacío
        assertFalse(ReservaValidator.camposObligatoriosCompletos(r));
    }

    @Test
    void camposObligatoriosCompletos_faltaEmail_devuelveFalse() {
        Reserva r = crearReservaBasica();
        r.setEmail("   "); // solo espacios
        assertFalse(ReservaValidator.camposObligatoriosCompletos(r));
    }

    // ---------- TESTS EMAIL ----------

    @Test
    void emailValido_formatoCorrecto_devuelveTrue() {
        assertTrue(ReservaValidator.emailValido("usuario@empresa.es"));
    }

    @Test
    void emailValido_noTerminaEnEs_devuelveFalse() {
        assertFalse(ReservaValidator.emailValido("usuario@gmail.com"));
    }

    @Test
    void emailValido_nullOVacio_devuelveFalse() {
        assertFalse(ReservaValidator.emailValido(null));
        assertFalse(ReservaValidator.emailValido(""));
        assertFalse(ReservaValidator.emailValido("   "));
    }
}
