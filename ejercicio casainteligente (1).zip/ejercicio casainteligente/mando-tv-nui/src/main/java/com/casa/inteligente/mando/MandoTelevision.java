package com.casa.inteligente.mando;

/**
 * Clase que representa un mando de televisión muy sencillo.
 * Controla solo el volumen.
 */
public class MandoTelevision {

    private int volumen;
    private int volumenMinimo;
    private int volumenMaximo;

    public MandoTelevision() {
        this.volumenMinimo = 0;
        this.volumenMaximo = 100;
        this.volumen = 10; // volumen inicial
    }

    public MandoTelevision(int volumenMinimo, int volumenMaximo, int volumenInicial) {
        this.volumenMinimo = volumenMinimo;
        this.volumenMaximo = volumenMaximo;
        if (volumenInicial < volumenMinimo) {
            this.volumen = volumenMinimo;
        } else if (volumenInicial > volumenMaximo) {
            this.volumen = volumenMaximo;
        } else {
            this.volumen = volumenInicial;
        }
    }

    /** Sube el volumen en una unidad, sin superar el máximo */
    public void subirVolumen() {
        if (volumen < volumenMaximo) {
            volumen++;
        }
        System.out.println("Volumen actual: " + volumen);
    }

    /** Baja el volumen en una unidad, sin bajar del mínimo */
    public void bajarVolumen() {
        if (volumen > volumenMinimo) {
            volumen--;
        }
        System.out.println("Volumen actual: " + volumen);
    }

    public int getVolumen() {
        return volumen;
    }

    public void setVolumen(int volumen) {
        if (volumen < volumenMinimo) {
            this.volumen = volumenMinimo;
        } else if (volumen > volumenMaximo) {
            this.volumen = volumenMaximo;
        } else {
            this.volumen = volumen;
        }
    }

    public int getVolumenMinimo() {
        return volumenMinimo;
    }

    public int getVolumenMaximo() {
        return volumenMaximo;
    }

    @Override
    public String toString() {
        return "MandoTelevision{volumen=" + volumen + "}";
    }
}
