package com.casa.inteligente.gestos;

import com.casa.inteligente.mando.MandoTelevision;

import org.bytedeco.javacv.CanvasFrame;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.OpenCVFrameConverter;
import org.bytedeco.javacv.OpenCVFrameGrabber;

import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_core.Point;
import org.bytedeco.opencv.opencv_core.Rect;
import org.bytedeco.opencv.opencv_core.Scalar;
import org.bytedeco.opencv.opencv_core.Size;

import static org.bytedeco.opencv.global.opencv_core.absdiff;
import static org.bytedeco.opencv.global.opencv_core.countNonZero;

import static org.bytedeco.opencv.global.opencv_imgproc.COLOR_BGR2GRAY;
import static org.bytedeco.opencv.global.opencv_imgproc.GaussianBlur;
import static org.bytedeco.opencv.global.opencv_imgproc.cvtColor;
import static org.bytedeco.opencv.global.opencv_imgproc.line;
import static org.bytedeco.opencv.global.opencv_imgproc.putText;
import static org.bytedeco.opencv.global.opencv_imgproc.threshold;
import static org.bytedeco.opencv.global.opencv_imgproc.THRESH_BINARY;
import static org.bytedeco.opencv.global.opencv_imgproc.FONT_HERSHEY_SIMPLEX;
import static org.bytedeco.opencv.global.opencv_imgproc.LINE_AA;

/**
 * Detección de movimiento en lado izquierdo/derecho de la cámara
 * y control de volumen del MandoTelevision (con realidad aumentada).
 */
public class DeteccionMovimientoAR {

    private MandoTelevision mando;

    public DeteccionMovimientoAR(MandoTelevision mando) {
        this.mando = mando;
    }

    public void iniciar() {

        OpenCVFrameGrabber webcam = new OpenCVFrameGrabber(0);
        OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();

        try {
            webcam.start();

            CanvasFrame ventana = new CanvasFrame("Control AR - Movimiento");
            ventana.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
            ventana.setCanvasSize(640, 480);

            Mat frameActual = new Mat();
            Mat framePrevioGris = new Mat();
            Mat frameGris = new Mat();
            Mat diferencia = new Mat();
            Mat umbral = new Mat();

            while (ventana.isVisible()) {

                Frame frame = webcam.grab();
                if (frame == null) {
                    continue;
                }

                frameActual = converter.convert(frame);

                // Escala de grises + suavizado
                cvtColor(frameActual, frameGris, COLOR_BGR2GRAY);
                GaussianBlur(frameGris, frameGris, new Size(21, 21), 0);

                // Si es el primer frame, se usa como referencia
                if (framePrevioGris.empty()) {
                    framePrevioGris = frameGris.clone();
                    continue;
                }

                // Diferencia entre frames
                absdiff(framePrevioGris, frameGris, diferencia);
                threshold(diferencia, umbral, 20, 255, THRESH_BINARY);

                int ancho = umbral.cols();
                int alto = umbral.rows();

                // Zonas izquierda / derecha (tercio izquierdo y tercio derecho)
                Rect zonaIzquierda = new Rect(0, 0, ancho / 3, alto);
                Rect zonaDerecha = new Rect(ancho * 2 / 3, 0, ancho / 3, alto);

                Mat izquierda = new Mat(umbral, zonaIzquierda);
                Mat derecha = new Mat(umbral, zonaDerecha);

                int movIzq = countNonZero(izquierda);
                int movDer = countNonZero(derecha);

                int umbralMovimiento = 30000; // ajustable según nuestra cámara

                if (movIzq > umbralMovimiento) {
                    System.out.println("Movimiento en IZQUIERDA -> SUBIR volumen");
                    mando.subirVolumen();
                }

                if (movDer > umbralMovimiento) {
                    System.out.println("Movimiento en DERECHA -> BAJAR volumen");
                    mando.bajarVolumen();
                }

                // --- Realidad aumentada: texto del volumen ---
                putText(
                        frameActual,
                        "Volumen: " + mando.getVolumen(),
                        new Point(20, 30),
                        FONT_HERSHEY_SIMPLEX,
                        1.0,
                        new Scalar(0, 255, 0, 0),
                        2,
                        LINE_AA,
                        false
                );

                // --- Línea vertical en el centro de la imagen ---
                line(
                        frameActual,
                        new Point(ancho / 2, 0),
                        new Point(ancho / 2, alto),
                        new Scalar(0, 255, 0, 0),
                        2,
                        LINE_AA,
                        0
                );

                ventana.showImage(converter.convert(frameActual));

                // Guardamos el frame actual en gris para la próxima iteración
                framePrevioGris = frameGris.clone();
            }

            webcam.stop();
            ventana.dispose();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // MAIN de 
    public static void main(String[] args) {
        MandoTelevision mando = new MandoTelevision();
        DeteccionMovimientoAR ar = new DeteccionMovimientoAR(mando);
        ar.iniciar();
    }
}

