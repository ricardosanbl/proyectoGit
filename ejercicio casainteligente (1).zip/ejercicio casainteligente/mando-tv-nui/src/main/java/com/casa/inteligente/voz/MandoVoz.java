package com.casa.inteligente.voz;

import com.casa.inteligente.mando.MandoTelevision;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.LibVosk;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;
import java.io.IOException;

/**
 * Clase que controla el MandoTelevision mediante comandos de voz
 * usando Vosk.
 */
public class MandoVoz {

    private MandoTelevision mando;
    private String rutaModelo;

    public MandoVoz(MandoTelevision mando, String rutaModelo) {
        this.mando = mando;
        this.rutaModelo = rutaModelo;
    }

    /**
     * Inicia la escucha por micrófono.
     * Reconoce "subir volumen" y "bajar volumen".
     */
    public void iniciar() {

        // No usamos setLogLevel porque nuestra versión de Vosk no lo admite con int ni con enum

        try (Model model = new Model(rutaModelo)) {

            float sampleRate = 16000.0f; // frecuencia recomendada por Vosk

            try (Recognizer recognizer = new Recognizer(model, sampleRate)) {

                AudioFormat format = new AudioFormat(sampleRate, 16, 1, true, false);
                DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);

                if (!AudioSystem.isLineSupported(info)) {
                    System.err.println("Micrófono no soportado en este formato.");
                    return;
                }

                TargetDataLine mic = (TargetDataLine) AudioSystem.getLine(info);
                mic.open(format);
                mic.start();

                System.out.println("Escuchando... di 'subir volumen' o 'bajar volumen'.");
                System.out.println("Pulsa Ctrl + C para detener.");

                byte[] buffer = new byte[4096];

                while (true) {
                    int bytesRead = mic.read(buffer, 0, buffer.length);
                    if (bytesRead < 0) {
                        break;
                    }

                    if (recognizer.acceptWaveForm(buffer, bytesRead)) {
                        String resultado = recognizer.getResult();
                        procesarResultado(resultado);
                    }
                }

            } catch (LineUnavailableException e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            System.err.println("Error cargando el modelo VOSK: " + e.getMessage());
        }
    }

    /**
     * Procesa el JSON que devuelve Vosk.
     */
    private void procesarResultado(String json) {
        System.out.println("Reconocido: " + json);

        String texto = json.toLowerCase();

        if (texto.contains("subir volumen")) {
            mando.subirVolumen();
        } else if (texto.contains("bajar volumen")) {
            mando.bajarVolumen();
        }
    }

    /**
     * Método main para probar esta clase.
     */
    public static void main(String[] args) {

        // CAMBIA ESTA RUTA POR LA TUYA REAL
        String rutaModelo = "C:/vosk-model-small-es-0.42";

        MandoTelevision mando = new MandoTelevision();
        MandoVoz voz = new MandoVoz(mando, rutaModelo);

        voz.iniciar();
    }
}


