package herenciaa;

public class Informatico extends empleado {
	  
		   private String especialidad;
		   // constructor sin parametros
		   public Informatico() {}
		   // constructor con parametros
		   public Informatico(String nombre,int edad,double salario,String especialidad) {
			   super(nombre,edad,salario);			 
			   this.especialidad=especialidad;	   
		   }
		   //getters y setters
			  public String getEspecialidad() {
				  return especialidad;
			  }
			  public void setEspecialidad(String especialidad) {
				  this.especialidad=especialidad;
		  }
		
		}
			  
			  	   
		   
	   


