package herenciaa;

public class Contable extends empleado {
	 
		   private int numClientes;
		   // constructor sin parametros
		   public Contable() {}
		   // constructor con parametros
		   public Contable(String nombre, int edad,double salario,int numClientes) {
			   super(nombre,edad,salario);	   
			   this.numClientes=numClientes;
		   }
		   // getters y setters
		
			  public int getNumClientes() {
				  return numClientes;		  
			  }
			  public void setNumClientes(int numClientes) {
				  this.numClientes=numClientes;
			
		  }
			
	  }


