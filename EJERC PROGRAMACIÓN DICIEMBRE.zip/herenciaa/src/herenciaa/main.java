package herenciaa;

public class main {

	public static void main(String[] args) {
		//administrativo usando constructor con parametros
		Administrativo admin= new Administrativo("Antonio",35,1600,"Recursos Humanos");
		
		//Contable usando constructor con parametros
		Contable contable= new Contable("Susana",32,1800,25);
		
		//Informatico usando constructor con parametros
		Informatico informatico= new Informatico("Jose",37,2200,"Seguridad");
		
		//administrativo usando constructor sin parametros
		Administrativo admin2= new Administrativo();
		admin2.setNombre("Ana");
		admin2.setEdad(38);
		admin2.setSalario(2000);
		admin2.setDepartamento("Finanzas");
		//contable usando constructor sin parametros
		Contable contable2= new Contable();
		contable2.setNombre("Ricardo");
		contable2.setEdad(45);
		contable2.setSalario(2500);
		contable2.setNumClientes(48);
		
		//mostrar datos
		System.out.println("Administrativo 1: " + admin.getNombre() + ", Departamento: " + admin.getDepartamento() + ", Edad: " + admin.getEdad());
		System.out.println("-------------------------------------------------------------------------------------------------------------");
		System.out.println("Contable 1: " + contable.getNombre() + ", Clientes: " + contable.getNumClientes() +  ", Sueldo: " + contable.getSalario());
		System.out.println("-------------------------------------------------------------------------------------------------------------");
		System.out.println("Informatico 1: " + informatico.getNombre() + ", Especialidad: " + informatico.getEspecialidad() + ", Edad: " + informatico.getEdad());
		System.out.println("-------------------------------------------------------------------------------------------------------------");
		System.out.println("Administrativo 2: " + admin2.getNombre() + ", Edad: " + admin2.getEdad() + ", Departamento: " + admin2.getDepartamento());
		System.out.println("-------------------------------------------------------------------------------------------------------------");
		System.out.println("Contable 2: " + contable2.getNombre() + " , Edad: " + contable2.getEdad() + ", Sueldo: " + contable2.getSalario());
		
		
		

	}

}
