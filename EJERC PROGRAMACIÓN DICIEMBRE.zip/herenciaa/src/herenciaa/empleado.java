package herenciaa;

public class empleado {
	private String nombre;
	private int edad;
	private double salario;
	//constructor sin parametros
	public empleado() {}
	//construstor con parametros
	public empleado(String nombre,int edad,double salario) {
		this.nombre = nombre ;
		this.edad= edad;
		this.salario= salario;
		}
	
	//Getters y Setters
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad= edad;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario= salario;
	}
}



