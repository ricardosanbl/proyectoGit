package herenciaa;



public class Administrativo extends empleado{
		  private String departamento;
		  // constructor sin parametros
		  public Administrativo() {}
			  //constructor con parametros
			  public Administrativo (String nombre,int edad, double salario,String departamento) {
				  super(nombre,edad,salario);
				  this.departamento= departamento;
				  
			  }
			  // geeters y setters
			 
			  public String getDepartamento() {
				  return departamento;
			  }
			  public void setDepartamento(String departamento) {
				  this.departamento= departamento;
				  
		  }
		
		}
			  
	    	
	    




