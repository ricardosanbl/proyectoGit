 package correo;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class GmailSmtpClient {

    private final String smtpHost;
    private final int smtpPort;

    private String sender;
    private final List<String> recipients = new ArrayList<>();
    private String subject = "";
    private String body = "";

    // Constructor (host y puerto al instanciar)
    public GmailSmtpClient(String smtpHost, int smtpPort) {
        this.smtpHost = smtpHost;
        this.smtpPort = smtpPort;
    }

    // a) añadir varios destinatarios
    public void addRecipients(String[] recipients) {
        if (recipients == null) return;
        for (String r : recipients) addRecipient(r);
    }

    // b) añadir un destinatario
    public void addRecipient(String recipient) {
        if (recipient == null || recipient.trim().isEmpty()) return;
        this.recipients.add(recipient.trim());
    }

    // c) remitente
    public void setSender(String psender) {
        this.sender = psender;
    }

    // d) asunto
    public void setSubject(String subject) {
        this.subject = subject;
    }

    // e) cuerpo
    public void setMailText(String pbody) {
        this.body = pbody;
    }

    // ---------------------------------------------------
    // ENVIAR USANDO SSL (Puerto 465)
    // ---------------------------------------------------
    public void sendUsingSSLAuthentication(final String user, final String pass) throws MessagingException {

        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", String.valueOf(smtpPort));
        props.put("mail.smtp.auth", "true");

        // SSL directo
        props.put("mail.smtp.ssl.enable", "true");

        // ✅ SOLUCIÓN PARA ERROR PKIX (certificado)
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        props.put("mail.smtp.ssl.checkserveridentity", "false");

        // (Extra: fuerza protocolo, por si la red da problemas)
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, pass);
            }
        });

        Message message = buildMessage(session);
        Transport.send(message);
    }

    // ---------------------------------------------------
    // ENVIAR USANDO TLS STARTTLS (Puerto 587)
    // ---------------------------------------------------
    public void sendUsingTLSAuthentication(final String user, final String pass) throws MessagingException {

        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", String.valueOf(smtpPort));
        props.put("mail.smtp.auth", "true");

        // STARTTLS
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.starttls.required", "true");

        // ✅ SOLUCIÓN PARA ERROR PKIX (certificado)
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        props.put("mail.smtp.ssl.checkserveridentity", "false");

        // (Extra: fuerza protocolo)
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, pass);
            }
        });

        Message message = buildMessage(session);
        Transport.send(message);
    }

    // ---------------------------------------------------
    // ENVIAR SIN AUTENTICACIÓN (Gmail normalmente lo rechaza)
    // ---------------------------------------------------
    public void send() throws MessagingException {

        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", String.valueOf(smtpPort));
        props.put("mail.smtp.auth", "false");

        Session session = Session.getInstance(props);
        Message message = buildMessage(session);
        Transport.send(message);
    }

    // ---------------------------------------------------
    // Construcción del mensaje
    // ---------------------------------------------------
    private Message buildMessage(Session session) throws MessagingException {

        if (sender == null || sender.trim().isEmpty()) {
            throw new MessagingException("Falta el remitente. Llama a setSender().");
        }

        if (recipients.isEmpty()) {
            throw new MessagingException("Faltan destinatarios. Llama a addRecipient/addRecipients().");
        }

        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(sender));

        for (String r : recipients) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(r));
        }

        message.setSubject(subject, StandardCharsets.UTF_8.name());
        message.setText(body, StandardCharsets.UTF_8.name());

        return message;
    }
}

               