package correo;

public class Main {

    public static void main(String[] args) {

        try {
            // ✅ SSL directo (puerto 465)
            GmailSmtpClient client = new GmailSmtpClient("smtp.gmail.com", 465);

            // REMITENTE
            client.setSender("TU_CORREO@gmail.com");

            // DESTINATARIO
            client.addRecipient("DESTINO@gmail.com");

            // ASUNTO
            client.setSubject("Prueba JavaMail por SSL (465)");

            // CUERPO
            client.setMailText("Hola! Este correo se ha enviado desde Eclipse usando JavaMail con SSL (puerto 465).");

            // ✅ IMPORTANTE:
            // En pass ponemos una APP PASSWORD (contraseña de aplicación)
            client.sendUsingSSLAuthentication("markezricky@gmail.com", "bqoeojonmplsisie");

            System.out.println("✅ CORREO ENVIADO CORRECTAMENTE");

        } catch (Exception e) {
            System.out.println("❌ ERROR: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
