package servidor;

import java.net.*;

public class AlarmaServidor {
    public static void main(String[] args) {
        DatagramSocket socket = null;
        try {
            // Crear el socket UDP para escuchar en un puerto específico
            socket = new DatagramSocket(9878); // El mismo puerto que el cliente usa
            System.out.println("Servidor esperando mensajes...");

            byte[] receiveData = new byte[1024]; // Buffer para recibir datos

            while (true) {
                // Recibir el mensaje del cliente
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);  // Recibe el paquete UDP del cliente

                // Convertir el mensaje recibido a String
                String mensajeRecibido = new String(receivePacket.getData(), 0, receivePacket.getLength());

                // Mostrar el mensaje recibido por consola
                System.out.println("Mensaje recibido: " + mensajeRecibido);
            }

        } catch (Exception e) {
            System.out.println("Error en el servidor: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close(); // Cerrar el socket si se abrió correctamente
            }
        }
    }
}

