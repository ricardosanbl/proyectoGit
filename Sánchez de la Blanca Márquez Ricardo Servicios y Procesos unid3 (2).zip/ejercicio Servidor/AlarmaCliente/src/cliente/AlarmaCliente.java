package cliente;

import java.net.*;

public class AlarmaCliente {
    public static void main(String[] args) {
        try {
            // Dirección IP y puerto del servidor
            InetAddress serverAddress = InetAddress.getByName("localhost"); // IP del servidor
            int serverPort = 9876; // Puerto en el servidor

            // Crear un socket UDP
            DatagramSocket socket = new DatagramSocket();

            // Mensajes que se enviarán
            String[] mensajes = {
                "INFO: El sistema de alarma está activo.",
                "WARNING: Se ha detectado un movimiento sospechoso.",
                "ALERT: Se ha activado la alarma de seguridad."
            };

            // Enviar los mensajes uno por uno
            for (String mensaje : mensajes) {
                DatagramPacket packet = new DatagramPacket(mensaje.getBytes(), mensaje.length(), serverAddress, serverPort);
                socket.send(packet); // Enviar mensaje al servidor
                System.out.println("Mensaje enviado: " + mensaje);
                Thread.sleep(1000); // Esperar 1 segundo antes de enviar el siguiente mensaje
            }

            socket.close(); // Cerrar el socket al final
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

