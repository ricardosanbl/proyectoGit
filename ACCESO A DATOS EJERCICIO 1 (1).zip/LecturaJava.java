import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LecturaJava {

    // Método que lee el fichero y muestra cada línea y número de caracteres
    public static void leerFichero(String ruta) throws FileNotFoundException, IOException {
        String linea = "";
        int contadorLineas = 0;

        // Se crea el objeto FileReader, que abre el fichero en modo lectura
        FileReader fr = new FileReader(ruta);

        // BufferedReader mejora el rendimiento y permite leer línea a línea
        BufferedReader br = new BufferedReader(fr);

        // Bucle para leer cada línea mientras no sea nula (fin del archivo)
        while ((linea = br.readLine()) != null) {
            contadorLineas++; // Incrementa el número de líneas
            int numCaracteres = linea.length(); // Calcula el número de caracteres
            System.out.println("Línea " + contadorLineas + ": " + linea);
            System.out.println("→ Número de caracteres: " + numCaracteres);
            System.out.println("--------------------------------------");
        }

        // Cierre del flujo de lectura
        br.close();

        // Muestra cuántas líneas se leyeron en total
        System.out.println("Total de líneas leídas: " + contadorLineas);
    }

    // Método principal (punto de entrada del programa)
    public static void main(String[] args) {
        try {
            // Llamamos al método con la ruta absoluta del fichero
            leerFichero("C:\\Users\\sanbl\\Desktop\\Nueva carpeta\\prueba.txt");

        } catch (FileNotFoundException e) {
            System.out.println("❌ Error: No se encontró el archivo especificado.");
        } catch (IOException e) {
            System.out.println("❌ Error de lectura del fichero.");
        }
    }
}





