package com.refactorizacion;

public interface IEmpelado {

	String getNombre();

	double getSalario();

}