
package com.refactorizacion;

public class Persona {
    private String nombre = "Ana López";

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}