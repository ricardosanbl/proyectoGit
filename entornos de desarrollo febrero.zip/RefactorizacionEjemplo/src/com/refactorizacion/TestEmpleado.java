
		package com.refactorizacion;

		public class TestEmpleado {
		    public static void main(String[] args) {
		        IEmpelado emp = new Empleado();
		        System.out.println("Nombre: " + emp.getNombre());
		        System.out.println("Salario: " + emp.getSalario());
		    }
		
		// TODO Auto-generated method stub

	}


