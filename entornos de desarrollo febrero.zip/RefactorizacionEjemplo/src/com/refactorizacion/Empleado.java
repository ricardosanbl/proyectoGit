
	package com.refactorizacion;

public class Empleado implements IEmpelado {
    private String nombre = "Juan Pérez";
    private double salario = 3000.0;

    @Override
	public String getNombre() {
        return nombre;
    }

    @Override
	public double getSalario() {
        return salario;
    }
}
