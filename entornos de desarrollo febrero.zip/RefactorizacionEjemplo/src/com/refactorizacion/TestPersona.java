
		package com.refactorizacion;

		public class TestPersona {
		    public static void main(String[] args) {
		        Persona persona = new Persona();
		        System.out.println("Nombre: " + persona.getNombre());
		        
		        persona.setNombre("Carlos Gómez");
		        System.out.println("Nuevo Nombre: " + persona.getNombre());
		    }
		}


		

