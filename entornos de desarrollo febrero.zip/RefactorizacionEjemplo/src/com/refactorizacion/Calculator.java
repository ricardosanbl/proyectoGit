
		package com.refactorizacion;

		public class Calculator {
		    public static void main(String[] args) {
		        Calculator calc = new Calculator();
		        calc.operaciones(10, 5);
		    }

		    public void operaciones(int a, int b) {
		        int resultado = a + b;
		        mostrarResultado(resultado);
		    }

			private void mostrarResultado(int resultado) {
				System.out.println("Resultado: " + resultado);
			}
		


	}


