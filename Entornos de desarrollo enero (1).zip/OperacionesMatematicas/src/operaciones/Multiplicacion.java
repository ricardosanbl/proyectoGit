package operaciones;

public class Multiplicacion {
    private int num1;
    private int num2;

    // Constructor
    public Multiplicacion(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    // Método para realizar la operación de multiplicación
    public int realizarMultiplicacion() {
        return num1 * num2;
    }

    // Métodos getter y setter
    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }
}
	


