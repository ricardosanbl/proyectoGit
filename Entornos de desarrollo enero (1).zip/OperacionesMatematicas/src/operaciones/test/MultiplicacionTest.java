package operaciones.test;
	
	import static org.junit.Assert.assertEquals;
	import org.junit.Test;
	import operaciones.Multiplicacion;

	public class MultiplicacionTest {

	    @Test
	    public void testRealizarMultiplicacion() {
	        Multiplicacion multiplicacion = new Multiplicacion(4, 5);
	        int resultado = multiplicacion.realizarMultiplicacion();
	        assertEquals(20, resultado);
	    }
	}



