package operaciones.test;


	import static org.junit.Assert.assertEquals;
	import static org.junit.Assert.assertThrows;
	import org.junit.Test;
	import operaciones.Division;

	public class DivisionTest {

	    @Test
	    public void testRealizarDivision() {
	        Division division = new Division(10, 2);
	        double resultado = division.realizarDivision();
	        assertEquals(5.0, resultado, 0.01);
	    }

	    @Test
	    public void testDividirPorCero() {
	        Division division = new Division(10, 0);
	        assertThrows(ArithmeticException.class, () -> {
	            division.realizarDivision();
	        });
	    }
	}



