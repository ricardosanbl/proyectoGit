package operaciones.test;
	
	import static org.junit.Assert.assertEquals;
	import org.junit.Test;
	import operaciones.Resta;

	public class RestaTest {

	    @Test
	    public void testRealizarResta() {
	        Resta resta = new Resta(10, 5);
	        int resultado = resta.realizarResta();
	        assertEquals(5, resultado);
	    }
	}



