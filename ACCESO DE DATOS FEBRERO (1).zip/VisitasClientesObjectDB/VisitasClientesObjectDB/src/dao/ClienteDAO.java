package dao;

import config.JPAUtil;
import model.Cliente;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

public class ClienteDAO {

    // CREATE
    public Cliente crear(Cliente cliente) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(cliente);
            em.getTransaction().commit();
            return cliente;
        } finally {
            em.close();
        }
    }

    // READ - listar todos
    public List<Cliente> listar() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Cliente> query =
                    em.createQuery("SELECT c FROM Cliente c", Cliente.class);

            List<Cliente> clientes = query.getResultList();

            // Fuerza la carga de visitas antes de cerrar
            clientes.forEach(c -> c.getVisitas().size());

            return clientes;
        } finally {
            em.close();
        }
    }

    // READ - buscar por ID (corregido)
    public Cliente buscarPorId(Long id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            Cliente c = em.find(Cliente.class, id);

            if (c != null) {
                c.getVisitas().size(); // Fuerza carga de la colección
            }

            return c;
        } finally {
            em.close();
        }
    }

    // UPDATE - actualizar comercial
    public boolean actualizarComercial(Long id, String nuevoComercial) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();

            Cliente c = em.find(Cliente.class, id);

            if (c == null) {
                em.getTransaction().rollback();
                return false;
            }

            c.setComercialPrincipal(nuevoComercial);

            em.getTransaction().commit();
            return true;

        } finally {
            em.close();
        }
    }

    // UPDATE - añadir visita
    public boolean añadirVisita(Long id, Date fechaVisita) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();

            Cliente c = em.find(Cliente.class, id);

            if (c == null) {
                em.getTransaction().rollback();
                return false;
            }

            c.addVisita(fechaVisita);

            em.getTransaction().commit();
            return true;

        } finally {
            em.close();
        }
    }

    // DELETE
    public boolean eliminar(Long id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();

            Cliente c = em.find(Cliente.class, id);

            if (c == null) {
                em.getTransaction().rollback();
                return false;
            }

            em.remove(c);

            em.getTransaction().commit();
            return true;

        } finally {
            em.close();
        }
    }
}
   
          
