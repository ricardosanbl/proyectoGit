package app;

import config.JPAUtil;
import dao.ClienteDAO;
import model.Cliente;
import ui.ConsolaUI;

import java.util.Date;

public class Main {

    public static void main(String[] args) {

        ClienteDAO dao = new ClienteDAO();
        ConsolaUI ui = new ConsolaUI();
        boolean salir = false;

        while (!salir) {
            int op = ui.menu();

            switch (op) {
                case 1 -> {
                    String nombre = ui.texto("Nombre: ");
                    String a1 = ui.texto("Apellido 1: ");
                    String a2 = ui.texto("Apellido 2: ");
                    String comercial = ui.texto("Comercial principal: ");
                    Long idEmpresa = ui.numeroLong("ID empresa: ");

                    Cliente c = new Cliente(nombre, a1, a2, comercial, idEmpresa);
                    dao.crear(c);
                    System.out.println("✅ Cliente creado: " + c);
                }
                case 2 -> dao.listar().forEach(System.out::println);

                case 3 -> {
                    Long id = ui.numeroLong("ID cliente: ");
                    Cliente c = dao.buscarPorId(id);
                    System.out.println(c != null ? c : "❌ No existe");
                }
                case 4 -> {
                    Long id = ui.numeroLong("ID cliente: ");
                    boolean ok = dao.añadirVisita(id, new Date());
                    System.out.println(ok ? "✅ Visita añadida" : "❌ No existe");
                }
                case 5 -> {
                    Long id = ui.numeroLong("ID cliente: ");
                    String nuevo = ui.texto("Nuevo comercial: ");
                    boolean ok = dao.actualizarComercial(id, nuevo);
                    System.out.println(ok ? "✅ Actualizado" : "❌ No existe");
                }
                case 6 -> {
                    Long id = ui.numeroLong("ID cliente: ");
                    boolean ok = dao.eliminar(id);
                    System.out.println(ok ? "✅ Eliminado" : "❌ No existe");
                }
                case 0 -> salir = true;
                default -> System.out.println("Opción incorrecta");
            }
        }

        JPAUtil.close();
        System.out.println("Aplicación cerrada.");
    }
}
