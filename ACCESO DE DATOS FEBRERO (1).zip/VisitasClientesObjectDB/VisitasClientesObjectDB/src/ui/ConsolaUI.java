package ui;

import java.util.Scanner;

public class ConsolaUI {

    private final Scanner sc = new Scanner(System.in);

    public int menu() {
        System.out.println("\n=== MENÚ ===");
        System.out.println("1. Crear cliente");
        System.out.println("2. Listar clientes");
        System.out.println("3. Buscar por ID");
        System.out.println("4. Añadir visita");
        System.out.println("5. Actualizar comercial");
        System.out.println("6. Eliminar cliente");
        System.out.println("0. Salir");
        System.out.print("Opción: ");
        return Integer.parseInt(sc.nextLine());
    }

    public String texto(String msg) {
        System.out.print(msg);
        return sc.nextLine();
    }

    public Long numeroLong(String msg) {
        System.out.print(msg);
        return Long.parseLong(sc.nextLine());
    }
}