package com.empresa.asistencia.model;

import java.time.LocalDateTime;

public class RegistroAsistencia {

    private int id;
    private String nombre;
    private LocalDateTime horaEntrada;
    private LocalDateTime horaSalida;
    private String estado;

    public RegistroAsistencia(int id, String nombre, LocalDateTime horaEntrada, LocalDateTime horaSalida, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }

    public LocalDateTime getHoraSalida() {
        return horaSalida;
    }

    public String getEstado() {
        return estado;
    }
}