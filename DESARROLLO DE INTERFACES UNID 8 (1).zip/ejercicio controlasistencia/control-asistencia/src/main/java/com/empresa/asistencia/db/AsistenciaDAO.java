package com.empresa.asistencia.db;

import java.sql.*;

public class AsistenciaDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/control_asistencia";
    private static final String USER = "asistencia_user";
    private static final String PASSWORD = "1234";

    // Conexión
    public Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Registrar entrada
    public boolean registrarEntrada(String nombre) {

        if (nombre == null || nombre.trim().isEmpty()) {
            return false;
        }

        if (usuarioTieneEntradaAbierta(nombre)) {
            return false;
        }

        String sql = "INSERT INTO asistencia(nombre, hora_entrada, estado) VALUES (?, NOW(), 'ENTRADA')";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nombre);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Registrar salida
    public boolean registrarSalida(String nombre) {

        if (!usuarioTieneEntradaAbierta(nombre)) {
            return false;
        }

        String sql = """
                UPDATE asistencia 
                SET hora_salida = NOW(), estado = 'SALIDA'
                WHERE nombre = ? AND estado = 'ENTRADA'
                ORDER BY id DESC
                LIMIT 1
                """;

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nombre);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Comprobar si ya tiene entrada
    public boolean usuarioTieneEntradaAbierta(String nombre) {

        String sql = "SELECT COUNT(*) FROM asistencia WHERE nombre = ? AND estado = 'ENTRADA'";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nombre);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Contar registros
    public int contarRegistros() {

        String sql = "SELECT COUNT(*) FROM asistencia";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // Limpiar tabla (para tests)
    public void limpiarTabla() {

        String sql = "DELETE FROM asistencia";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}