package com.empresa.asistencia.ui;

import com.empresa.asistencia.db.AsistenciaDAO;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AppAsistencia extends Application {

    private final AsistenciaDAO dao = new AsistenciaDAO();

    @Override
    public void start(Stage stage) {
        Label titulo = new Label("Control de asistencia");
        titulo.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        TextField campoNombre = new TextField();
        campoNombre.setPromptText("Introduce el nombre del trabajador");

        Button botonEntrada = new Button("Registrar entrada");
        Button botonSalida = new Button("Registrar salida");

        botonEntrada.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        botonSalida.setStyle("-fx-background-color: #F44336; -fx-text-fill: white;");

        Label mensaje = new Label();

        botonEntrada.setOnAction(e -> {
            String nombre = campoNombre.getText();

            if (dao.registrarEntrada(nombre)) {
                mensaje.setText("Entrada registrada correctamente.");
            } else {
                mensaje.setText("No se pudo registrar la entrada. Puede que ya exista una entrada abierta.");
            }
        });

        botonSalida.setOnAction(e -> {
            String nombre = campoNombre.getText();

            if (dao.registrarSalida(nombre)) {
                mensaje.setText("Salida registrada correctamente.");
            } else {
                mensaje.setText("No se pudo registrar la salida. Puede que no exista entrada previa.");
            }
        });

        VBox root = new VBox(12);
        root.setPadding(new Insets(20));
        root.getChildren().addAll(titulo, campoNombre, botonEntrada, botonSalida, mensaje);

        Scene scene = new Scene(root, 430, 260);

        stage.setTitle("Control de asistencia");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}