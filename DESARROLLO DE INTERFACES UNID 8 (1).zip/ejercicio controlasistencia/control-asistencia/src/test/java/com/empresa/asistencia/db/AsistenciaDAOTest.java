package com.empresa.asistencia.db;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AsistenciaDAOTest {

    private AsistenciaDAO dao;

    @BeforeEach
    void setUp() {
        dao = new AsistenciaDAO();
        dao.limpiarTabla(); // limpiamos antes de cada test
    }

    // ✅ Prueba 1: Inserción correcta de entrada
    @Test
    void testInsercionEntrada() {
        boolean resultado = dao.registrarEntrada("Carlos");
        assertTrue(resultado);
    }

    // ✅ Prueba 2: Inserción correcta de salida
    @Test
    void testInsercionSalida() {
        dao.registrarEntrada("Ana");
        boolean resultado = dao.registrarSalida("Ana");
        assertTrue(resultado);
    }

    // ❌ Prueba 3: No permitir doble entrada
    @Test
    void testNoDobleEntrada() {
        dao.registrarEntrada("Luis");
        boolean resultado = dao.registrarEntrada("Luis");
        assertFalse(resultado);
    }

    // ❌ Prueba 4: No salida sin entrada
    @Test
    void testSalidaSinEntrada() {
        boolean resultado = dao.registrarSalida("Marta");
        assertFalse(resultado);
    }

    // 🔐 Prueba extra: SQL Injection
    @Test
    void testSQLInjection() {
        String nombre = "Pepe'; DROP TABLE asistencia; --";
        boolean resultado = dao.registrarEntrada(nombre);
        assertTrue(resultado);
    }

    // 📊 Prueba extra: volumen
    @Test
    void testVolumen() {
        for (int i = 0; i < 50; i++) {
            dao.registrarEntrada("Empleado" + i);
        }
        assertEquals(50, dao.contarRegistros());
    }
}